<?php
session_start();
require 'php/db_connect.php'; // Ensure this connects to your database

// Capture genres and search query
$selectedGenres = $_GET['genres'] ?? [];
$searchQuery = $_GET['query'] ?? '';

// Build the SQL query dynamically
if (!empty($selectedGenres) && $searchQuery) {
    $placeholders = implode(',', array_fill(0, count($selectedGenres), '?'));
    $sql = "SELECT * FROM Movies WHERE Title LIKE ? AND Genre IN ($placeholders) ORDER BY Title ASC";
    $params = array_merge(["%" . $searchQuery . "%"], $selectedGenres);
} elseif (!empty($selectedGenres)) {
    $placeholders = implode(',', array_fill(0, count($selectedGenres), '?'));
    $sql = "SELECT * FROM Movies WHERE Genre IN ($placeholders) ORDER BY Title ASC";
    $params = $selectedGenres;
} elseif ($searchQuery) {
    $sql = "SELECT * FROM Movies WHERE Title LIKE ? ORDER BY Title ASC";
    $params = ["%" . $searchQuery . "%"];
} else {
    $sql = "SELECT * FROM Movies ORDER BY Title ASC";
    $params = [];
}

$stmt = $conn->prepare($sql);

// Bind parameters dynamically
if (!empty($params)) {
    $types = str_repeat('s', count($params));
    $stmt->bind_param($types, ...$params);
}

$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Category</title>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="css/category.css">

  <script src="https://kit.fontawesome.com/14f233c83a.js" crossorigin="anonymous"></script>
</head>
<body>
  <div class="home">
    <!-- Sidebar -->
    <aside class="sidebar">
      <div class="logo">
        <i class="fa-solid fa-mug-hot logo-icon"></i>
        <h1>WATCH</h1>
      </div>
      <nav>
        <ul>
          <li><a href="index.php">Home</a></li>
          <li><a href="favourite.php">Favourites</a></li>
          <li><a href="category.php" class="active">Category</a></li>
          <?php if (isset($_SESSION['role']) && strtolower($_SESSION['role']) == 'admin'): ?><li><a href="addmovie.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'addmovie.php' ? 'active' : ''; ?>">Add a Movie</a></li><?php endif; ?>

        </ul>
      </nav>
      <div class="bottom-menu">
        <ul>
        <?php if (isset($_SESSION['user_id'])): ?>
            <li><a href="settings.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'settings.php' ? 'active' : ''; ?>">Settings</a></li>
        <?php endif; ?>
          <li><a href="php/logout.php">
              <?php echo isset($_SESSION['username']) ? 'Logout' : 'Login'; ?>
            </a>
          </li>
        </ul>
      </div>
    </aside>

    <!-- Main Content -->
    <main class="content">
      <!-- Header Section -->
      <header>
        <form action="category.php" method="GET" class="search-form">
          <input type="text" name="query" class="search-bar" placeholder="Search..." value="<?php echo htmlspecialchars($searchQuery); ?>" required>
          <button type="submit" style="display: none;"></button>
        </form>
        <div class="profile" class="profile-link">
          <span class="profile-name">
              <?php echo isset($_SESSION['username']) ? htmlspecialchars($_SESSION['username']) : 'Guest'; ?>
          </span>
      </div>

      </header>

      <!-- Movies Section -->
      <div class="main-content">
      <section class="category">
        <h1>
          <?php
          if ($searchQuery && !empty($selectedGenres)) {
              echo "Results for \"$searchQuery\" in selected genres";
          } elseif ($searchQuery) {
              echo "Search Results for \"$searchQuery\"";
          } elseif (!empty($selectedGenres)) {
              echo "Movies in selected genres";
          } else {
              echo "All Movies";
          }
          ?>
        </h1>
        <div class="category-grid">
          <?php if ($result && $result->num_rows > 0): ?>
            <?php while ($row = $result->fetch_assoc()): ?>
              <a href="moviePage.php?id=<?php echo $row['MovieID']; ?>" class="card" style="background-image: url('<?php echo $row['poster_path']; ?>');">
                <div class="card-text">
                  <h3><?php echo $row['Title']; ?></h3>
                  <p><?php echo $row['ReleaseDate']; ?> | <?php echo $row['Genre']; ?></p>
                </div>
              </a>
            <?php endwhile; ?>
          <?php else: ?>
            <p>No movies found matching your criteria.</p>
          <?php endif; ?>
        </div>
      </section>


        <!-- Genre Filter Section -->
        <aside class="filter">
        <h3>Genre</h3>
        <form action="category.php" method="GET" class="genre-form" id="genre-form">
        <ul>
          <?php
          $genres = [
            'action', 'adventure', 'animation', 'comedy', 'drama', 'horror',
            'romance', 'thriller', 'mystery', 'crime', 'family', 'sci-fi',
            'fantasy', 'documentary', 'music', 'musical', 'western', 'war', 'history'
          ];

          foreach ($genres as $genre) {
              $checked = in_array($genre, $_GET['genres'] ?? []) ? 'checked' : '';
              echo "<li>
                      <input type='checkbox' name='genres[]' value='$genre' $checked>
                      <label for='$genre'>" . ucfirst($genre) . "</label>
                    </li>";
          }
          ?>
        </ul>
      </form>
      </aside>
      </div>
    </main>
  </div>

  <script src="js/category.js"></script>
</body>
</html>
